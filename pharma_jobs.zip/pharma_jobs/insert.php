<?php
    
    $con = new mysqli("localhost","root","","pharma_all_jobs");
    
    $data = file_get_contents('php://input');
    
    $dt = json_decode($data);
    
    $username = $dt->username;
    $profilename = $dt->profilename;
    $profileheading = $dt->profileheading;
    $mobilenumber = $dt->mobilenumber;
    $email = $dt->email;
    $password = $dt->password;
    $status = $dt->status;
    
    
    $query = "insert into user_registration(username,profilename,profileheading,mobilenumber,email,password,status)values('$username','$profilename','$profileheading','$mobilenumber','$email','$password','$status')";
    
    $con->query($query);
    
    echo "Inserted"
?>
