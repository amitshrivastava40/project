//
//  main.swift
//  3_8
//
//  Created by TOPS on 8/3/18.
//  Copyright © 2018 abhishek. All rights reserved.
//

import Foundation

var a : Int = 10

var b : Int = 20


print("\(a) \(b)")
