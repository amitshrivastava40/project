//
//  ViewController1.swift
//  myproject
//
//  Created by TOPS on 8/3/18.
//  Copyright © 2018 abhishek. All rights reserved.
//

import UIKit

class ViewController1: UIViewController,UserDelegate {

    @IBOutlet weak var username: UITextField!

    @IBOutlet weak var profilename: UITextField!
    
    @IBOutlet weak var profileheading: UITextField!
    
    @IBOutlet weak var mobilenumber: UITextField!
    
    @IBOutlet weak var Email: UITextField!
    
    @IBOutlet weak var password: UITextField!
    
    @IBOutlet weak var status: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func buttonclick(_ sender: Any) {
        
        let obj = user_model(userid: 0, username: username.text!, profilename: profilename.text!, profileheading: profileheading.text!, mobilenumber: mobilenumber.text!, email: Email.text!, password: password.text!, status: status.text!);
        
        let objcnt = user_controller();
        
        objcnt.delegate = self;
        
        objcnt.InsertUserData(obj: obj);
    
    }
    
    func ReturnValue(stt: String) {
        print(stt);
    }

    @IBAction func username_val(_ sender: Any) {
        
        
    }

    @IBAction func mobilenum_val(_ sender: Any) {
        
        if isValidMobile(mobile: mobilenumber.text!) {
            
            mobilenumber.rightViewMode = .never
            mobilenumber.clipsToBounds = true
            mobilenumber.layer.borderWidth = 1
            mobilenumber.layer.borderColor = UIColor.green.cgColor
        }
        else {
            
            mobilenumber.rightViewMode = .whileEditing
            let imgview = UIImageView(image: UIImage(named: "if_Help_mark_query_question_support_talk_271504.png"))
            mobilenumber.rightView = imgview
            mobilenumber.clipsToBounds = true
            mobilenumber.layer.borderWidth = 1
            mobilenumber.layer.borderColor = UIColor.red.cgColor
        }
        
    }
    
    @IBAction func email_val(_ sender: Any) {
    }
    
    @IBAction func password_val(_ sender: Any) {
    }

    func isValidMobile(mobile: String) -> Bool {
        
        //STARTING WITH +91 THEN ONE DIGIT START BETWEEN 7 TO 9 THEN ADD 9 DIGIT BETWEEN 0 TO 9 IT PERMITS +919726174054 / 09726174054
        
        let PHONE_REGEX = "^([+][9][1]|[9][1]|[0]){0,1}([7-9]{1})([0-9]{9})$"
        
        let phoneTest = NSPredicate(format: "SELF MATCHES %@", PHONE_REGEX)
        let result =  phoneTest.evaluate(with: mobile)
        return result
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
