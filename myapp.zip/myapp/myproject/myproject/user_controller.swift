//
//  user_controller.swift
//  myproject
//
//  Created by TOPS on 8/16/18.
//  Copyright © 2018 abhishek. All rights reserved.
//

import UIKit

protocol UserDelegate {
    
    func ReturnValue(stt: String);
}

class user_controller: NSObject {
    
    var delegate : UserDelegate?
    
    func InsertUserData(obj : user_model)  {
        
        let url = URL(string: "http://localhost/pharma_jobs/insert.php")
        
        let dic = ["username":obj.username!,"profilename":obj.profilename!,"profileheading":obj.profileheading!,"mobilenumber":obj.mobilenumber!,"email":obj.email!,"password":obj.password!,"status":obj.status!]
        
        do {
            let finalbody = try JSONSerialization.data(withJSONObject: dic, options: []);
            var request = URLRequest(url: url!);
            
            request.addValue(String(finalbody.count), forHTTPHeaderField: "Content-length");
            
            request.httpBody = finalbody;
            
            request.httpMethod = "POST";
            
            let session = URLSession.shared;
            
            let datatask = session.dataTask(with: request)
            
            {(data1,rsp,err) in
                if err == nil
                {
                    
                    let strrsp = String(data: data1!, encoding: String.Encoding.utf8);
                    
                    DispatchQueue.main.async {
                        
                        self.delegate?.ReturnValue(stt: strrsp!)
                        
                    }
                    
                }
            
            }
            datatask.resume();
            
        } catch  {
            
        }
    }
    

}
