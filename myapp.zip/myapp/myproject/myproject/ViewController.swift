//
//  ViewController.swift
//  myproject
//
//  Created by TOPS on 8/3/18.
//  Copyright © 2018 abhishek. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var img: UIImageView!
    
    @IBOutlet weak var txtkeywords: UITextField!
    
    @IBOutlet weak var location: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func search(_ sender: Any) {
    }
    
    @IBAction func Register(_ sender: Any) {
        
        let stb = self.storyboard?.instantiateViewController(withIdentifier: "1");
        
        
        self.navigationController?.pushViewController(stb!, animated: true);
        
    }
    
    @IBAction func Login(_ sender: Any) {
        
        let stb = self.storyboard?.instantiateViewController(withIdentifier: "2");
        
        
        self.navigationController?.pushViewController(stb!, animated: true);

    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

