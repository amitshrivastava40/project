//
//  user_model.swift
//  myproject
//
//  Created by TOPS on 8/16/18.
//  Copyright © 2018 abhishek. All rights reserved.
//

import UIKit

class user_model: NSObject {
    
    var userid : Int?
    var username : String?
    var profilename : String?
    var profileheading : String?
    var mobilenumber : String?
    var email : String?
    var password : String?
    var status : String?
    
    init(userid : Int ,username : String ,profilename : String ,profileheading : String ,mobilenumber : String ,email : String ,password : String ,status : String) {
        
        self.userid = userid;
        self.username = username;
        self.profilename = profilename;
        self.profileheading = profileheading;
        self.mobilenumber = mobilenumber;
        self.email = email;
        self.password = password;
        self.status = status;
        
    }

}
