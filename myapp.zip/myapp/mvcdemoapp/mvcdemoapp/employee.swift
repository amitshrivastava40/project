//
//  employee.swift
//  mvcdemoapp
//
//  Created by TOPS on 8/4/18.
//  Copyright © 2018 abhishek. All rights reserved.
//

import UIKit

class employee: NSObject {
    
    var empid : Int?
    var empname : String?
    var empadd : String?
    var empmob : String?
    var empimg : String?
    
    init(empid : Int,
         empname: String,
         empadd: String,
         empmob: String,
         empimg: String) {
        
        self.empid = empid;
        self.empname = empname;
        self.empadd = empadd;
        self.empmob = empmob;
        self.empimg = empimg;
        
    }
    
    
    
    
    
    

}
