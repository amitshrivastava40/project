<?php
	
    $con=new mysqli("localhost","root","","webser");
  
    $data=file_get_contents('php://input');
    
    $dt = json_decode($data);
  
    $empname = $dt->empname;
    $empadd  = $dt->empadd;
    $empmob  =  $dt->empmob;
    
    define('UPLOAD_DIR', 'images/');
    
    $img = $dt->empimg;
    
    $img = str_replace('data:image/png;base64,', '', $img);
    $img = str_replace(' ', '+', $img);
    $data = base64_decode($img);
    $file = UPLOAD_DIR . uniqid() . '.png';
    $success = file_put_contents($file, $data);
    
  $query = "insert into emp_tbl(empname,empadd,empmob,empimg)values('$empname','$empadd','$empmob','$file')";
  $con->query($query);
  
    echo "success";
    
  /*   $qu = "select * from emp_tbl";
    
     $rows = $con->query($qu);
    while($row = $rows->fetch_assoc())
     {
        $pp[]  = $row;
        
     }
    
    echo json_encode($pp);
   */
    
?>
