//
//  ViewController.swift
//  mvcdemoapp
//
//  Created by TOPS on 8/4/18.
//  Copyright © 2018 abhishek. All rights reserved.
//

import UIKit

class ViewController: UIViewController,EmployeeDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate {

    @IBOutlet weak var img: UIImageView!
    
    @IBOutlet weak var txtempid: UITextField!
   
    @IBOutlet weak var txtempname: UITextField!
    
    @IBOutlet weak var txtempadd: UITextField!
    
    @IBOutlet weak var txtempmob: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let tap = UITapGestureRecognizer(target: self, action: #selector(self.test))
        
        tap.numberOfTapsRequired = 1;
        
        img.isUserInteractionEnabled = true;
        
        img.addGestureRecognizer(tap);
        
        
    }
    
    func test(sender:UITapGestureRecognizer)  {
        
        let picker = UIImagePickerController();
        
        picker.sourceType = .photoLibrary;
        
        picker.delegate = self;
        
        self.present(picker, animated: true, completion: nil);
        
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        
        let img1 = info[UIImagePickerControllerOriginalImage] as! UIImage
        
        img.image = img1;
        
        self.dismiss(animated: true, completion: nil);
        
        
    }
    @IBAction func buttonclick(_ sender: Any) {
        
        let imgdata = UIImageJPEGRepresentation(img.image!, 0.2)
        
        let base64data = imgdata?.base64EncodedString(options: Data.Base64EncodingOptions.lineLength64Characters);
        
        let obj = employee(empid: 0, empname: txtempname.text!, empadd: txtempadd.text!, empmob: txtempmob.text!, empimg: base64data!)
        
        let objcnt = employee_controller();
        
        objcnt.delegate = self;
        
        objcnt.InsertEmployeeData(obj: obj);
        
   
        
    }
    
    func ReturnValue(stt: String)  {
        print(stt);
    }
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

